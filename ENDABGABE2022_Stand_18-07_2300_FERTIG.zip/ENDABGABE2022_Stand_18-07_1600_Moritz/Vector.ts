
namespace EndabgabeSoSe22 {
    //Source: Jirkas Code (Asteroids/vector.ts)
    
    export class Vector {
        public x: number;
        public y: number;

        constructor(_x: number, _y: number) {
            this.x = _x;
            this.y = _y;
        }

        // public scale(_factor: number): void {
        //     this.x *= _factor;
        //     this.y *= _factor;
        // }

        // public add(_added: Vector): void {
        //     this.x += _added.x;
        //     this.y += _added.y;
        // }
    }
}