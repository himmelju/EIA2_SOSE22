"use strict";
var EndabgabeSoSe22;
(function (EndabgabeSoSe22) {
    //Source: Jirkas Code (Asteroids/vector.ts)
    class Vector {
        x;
        y;
        constructor(_x, _y) {
            this.x = _x;
            this.y = _y;
        }
    }
    EndabgabeSoSe22.Vector = Vector;
})(EndabgabeSoSe22 || (EndabgabeSoSe22 = {}));
//# sourceMappingURL=Vector.js.map